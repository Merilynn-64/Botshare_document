---
title: Overview
layout: default
---

# Open Robotics AI & Deep-Tech Initiative

Open Robotics AI & Deep-Tech Training is an open-source, hands-on initiative designed to equip learners with STEM, robotics, AI, and business development skills...
